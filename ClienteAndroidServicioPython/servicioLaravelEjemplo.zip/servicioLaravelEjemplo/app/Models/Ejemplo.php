<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Ejemplo extends Model
{
    use HasFactory;

       protected $table = 'personas'; //Por defecto tomaría la tabla 'personas'.
       protected $primaryKey = 'DNI';  //Por defecto el campo clave es 'id', entero y autonumérico.
       public $incrementing = false; //Para indicarle que la clave no es autoincremental.
       protected $keyType = 'string';   //Indicamos que la clave no es entera.
       public $timestamps = false;   //Con esto Eloquent no maneja automáticamente created_at ni updated_at.
       protected $fillable = ['DNI', 'Nombre', 'Clave','Tfno'];
       //protected $hidden = ['id'];
}
